window.$fire = function (event, ...args) {
    document.dispatchEvent(new CustomEvent('inject.fire', {
        detail:
        {
            type: event,
            payload: args
        }
    }))
    return `[inject.fire] ${event} [${args}]`
}