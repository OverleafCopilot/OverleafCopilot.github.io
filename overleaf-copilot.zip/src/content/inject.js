(function(){"use strict";window.$fire=function(t){document.dispatchEvent(new CustomEvent("inject-request",{detail:t}))}})();
